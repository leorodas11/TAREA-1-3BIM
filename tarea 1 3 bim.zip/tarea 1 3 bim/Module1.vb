﻿Imports MySql.Data.MySqlClient
Module Module1
    Public conectarmysql As MySqlConnection
    Public conectarmysqlcommand As MySqlCommand
End Module
