﻿Imports MySql.Data.MySqlClient
Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            conectarmysql = New MySqlConnection("server=localhost;" + "database=notas;user=root;password=;")
            conectarmysql.Open()
            conectarmysqlcommand = New MySqlCommand
            conectarmysqlcommand.CommandType = CommandType.Text
            conectarmysqlcommand.Connection = conectarmysql
        Catch ex As Exception
            MsgBox("Error nos falta ejecutar el SQL o el XAMPP" + ex.Message, MsgBoxStyle.Critical, "BD error")
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim Tabla As New DataTable
        Dim conexion As MySqlConnection
        Dim Ds As New DataSet
        conexion = New MySql.Data.MySqlClient.MySqlConnection
        conexion.ConnectionString = "server = 127.0.0.1; user = root; database = notas"
        Dim insertar As New MySqlDataAdapter("insert into notas(nombre, apellido, nota) values('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "')", conectarmysql)
        Try
            insertar.Fill(Tabla)
            MessageBox.Show("Se ha guardado la nota")
        Catch Mierror As MySqlException
            MessageBox.Show("Error, su registro no se completo")
        Finally
        End Try
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""

    End Sub
End Class
